self.__precacheManifest = [
  {
    "revision": "d74154e11a7d3e8d03e31dd356544010",
    "url": "/static/media/iced.d74154e1.png"
  },
  {
    "revision": "624b6216ce1d37a44785",
    "url": "/static/js/app.df2dcde3.chunk.js"
  },
  {
    "revision": "328a415775be7ae2ff6676ac0fcedad9",
    "url": "/static/media/suggestions.328a4157.png"
  },
  {
    "revision": "d1e0ba4d7260340fa2a971a7ed3af771",
    "url": "/static/media/icon.d1e0ba4d.png"
  },
  {
    "revision": "7a31fb919dd7c748dd503d955aa4363e",
    "url": "/static/media/pulse-pour.7a31fb91.gif"
  },
  {
    "revision": "8ad06df621a504e518b8cb0095ed654c",
    "url": "/static/media/dark-mode.8ad06df6.png"
  },
  {
    "revision": "f16959773581a57813f0",
    "url": "/static/js/runtime~app.91065de9.js"
  },
  {
    "revision": "de49b9087b79313d2f91",
    "url": "/static/js/2.8a74c15f.chunk.js"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/serve.json"
  },
  {
    "revision": "9000b6da33151808d8f691b377429bda",
    "url": "/manifest.json"
  },
  {
    "revision": "e727b772f87209154e29b00277737177",
    "url": "/index.html"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/favicon.ico"
  }
];