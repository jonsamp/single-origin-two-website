self.__precacheManifest = [
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "8ab25b47ef058e3130ac",
    "url": "/static/js/app.af5bd09f.chunk.js"
  },
  {
    "revision": "f16959773581a57813f0",
    "url": "/static/js/runtime~app.91065de9.js"
  },
  {
    "revision": "e408b392d02785328f9a4cd5b5ab0de0",
    "url": "/static/media/icon.e408b392.png"
  },
  {
    "revision": "d98a67fcb9c4afbda3b14363b80540a7",
    "url": "/static/media/pulse-pour.d98a67fc.gif"
  },
  {
    "revision": "8ad06df621a504e518b8cb0095ed654c",
    "url": "/static/media/dark-mode.8ad06df6.png"
  },
  {
    "revision": "d74154e11a7d3e8d03e31dd356544010",
    "url": "/static/media/iced.d74154e1.png"
  },
  {
    "revision": "328a415775be7ae2ff6676ac0fcedad9",
    "url": "/static/media/suggestions.328a4157.png"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/./fonts/Ionicons.ttf"
  },
  {
    "revision": "aebd8d74f47740d4769e3cf9a619d71d",
    "url": "/index.html"
  },
  {
    "revision": "8974e497bc5f5c9bf8560ea920397605",
    "url": "/manifest.json"
  },
  {
    "revision": "ebdad904679d00c84673",
    "url": "/static/js/2.3fa36d47.chunk.js"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/serve.json"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/favicon.ico"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/./fonts/Foundation.ttf"
  },
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/./fonts/Feather.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/./fonts/Entypo.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/./fonts/AntDesign.ttf"
  }
];